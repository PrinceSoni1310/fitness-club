import React from "react";
import { Box, Typography, Stack, Link } from "@mui/material";

const ContactUs = () => {
  return (
    <Box sx={{ mt: { lg: '100px', xs: '50px' }, px: '20px' }}>
      <Typography variant="h3" fontWeight="bold" mb={4}>
        Contact Us
      </Typography>

      <Stack spacing={2}>
        <Typography variant="h5">
          📞 Phone:{" "}
          <Link href="tel:+911234567891" underline="hover" color="#FF2625" fontWeight="bold">
            +91 1234567891
          </Link>
        </Typography>
        <Typography variant="h5">
          📧 Email:{" "}
          <Link href="mailto:princeysoni@gmail.com" underline="hover" color="#FF2625" fontWeight="bold">
            princeysoni@gmail.com
          </Link>
        </Typography>
      </Stack>
    </Box>
  );
};

export default ContactUs;
