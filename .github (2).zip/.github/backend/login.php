<?php
session_start();
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"));

$email = $data->email;
$password = $data->password;

$usersFile = '../backend/users.json'; // JSON data file

if (file_exists($usersFile)) {
    $users = json_decode(file_get_contents($usersFile), true);

    foreach ($users as $user) {
        if ($user['email'] === $email && $user['password'] === $password) {
            $_SESSION['user'] = $user; // Set session for frontend check
            echo json_encode(['success' => true, 'user' => $user]);
            exit;
        }
    }
}

echo json_encode(['success' => false, 'message' => 'Invalid credentials. Please register first.']);
?>
