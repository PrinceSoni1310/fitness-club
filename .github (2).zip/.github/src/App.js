import React, { useState } from "react";
import { Route, Routes, Navigate } from "react-router-dom";
import { Box } from "@mui/material";

import "./App.css";
import ExerciseDetail from "./pages/ExerciseDetail";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Exercises from "./components/Exercises";
import ContactUs from "./pages/ContactUs";
import AboutUs from "./pages/AboutUs";
import Account from "./pages/Account";

const App = () => {
  const isAuthenticated = localStorage.getItem("user");

  const [exercises, setExercises] = useState([]);
  const [bodyPart, setBodyPart] = useState("all");

  return (
    <Box sx={{ width: "100%", maxWidth: "1488px", mx: "auto" }}>
      <Navbar />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/exercise/:id" element={<ExerciseDetail />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/contact-us" element={<ContactUs />} />
        <Route path="/about-us" element={<AboutUs />} />
        <Route path="/account" element={isAuthenticated ? <Account /> : <Navigate to="/login" />} />
        <Route
          path="/exercise"
          element={
            isAuthenticated ? (
              <Exercises
                exercises={exercises}
                setExercises={setExercises}
                bodyPart={bodyPart}
              />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
      </Routes>

      <Footer />
    </Box>
  );
};

export default App;