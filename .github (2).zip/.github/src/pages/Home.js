import React from 'react';
import { Box, Typography, Container, Button, Grid, Paper } from '@mui/material';
import FitnessCenterIcon from '@mui/icons-material/FitnessCenter';
import RestaurantIcon from '@mui/icons-material/Restaurant';
import TrackChangesIcon from '@mui/icons-material/TrackChanges';
import VerifiedUserIcon from '@mui/icons-material/VerifiedUser';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';
import HeroBanner from '../components/HeroBanner';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const navigate = useNavigate();

  return (
    <Box sx={{ bgcolor: '#fefefe', pt: 2 }}>
      <HeroBanner />

      {/* Welcome Section */}
      <Container maxWidth="lg" sx={{ py: 6 }}>
        <Typography variant="h3" textAlign="center" fontWeight="bold" gutterBottom>
          💪 Welcome to FitLife
        </Typography>
        <Typography variant="h6" textAlign="center" color="text.secondary" maxWidth="md" mx="auto">
          FitLife is your ultimate fitness companion — helping you eat smart, train hard, and stay on track with your goals, all in one place.
        </Typography>
      </Container>

      {/* Highlights Section */}
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Grid container spacing={4}>
          {[
            { icon: <FitnessCenterIcon fontSize="large" color="primary" />, title: "Workout Plans", desc: "Customized routines tailored to your fitness level and goals." },
            { icon: <RestaurantIcon fontSize="large" color="primary" />, title: "Diet Guidance", desc: "Eat healthy with smart, structured meal plans." },
            { icon: <TrackChangesIcon fontSize="large" color="primary" />, title: "Track Progress", desc: "Monitor weight, age, height, and more with ease." },
            { icon: <VerifiedUserIcon fontSize="large" color="primary" />, title: "Secure Login", desc: "OTP verification for email and phone to keep your account safe." },
            { icon: <NotificationsActiveIcon fontSize="large" color="primary" />, title: "Reminders & Tips", desc: "Stay consistent with helpful nudges and motivational tips." },
          ].map((feature, index) => (
            <Grid item xs={12} sm={6} md={4} key={index}>
              <Paper elevation={4} sx={{ p: 3, borderRadius: 3, textAlign: 'center', height: '100%' }}>
                {feature.icon}
                <Typography variant="h6" fontWeight="bold" mt={2}>{feature.title}</Typography>
                <Typography color="text.secondary">{feature.desc}</Typography>
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* How It Works */}
      <Box sx={{ bgcolor: '#f5f5f5', py: 6 }}>
        <Container maxWidth="md">
          <Typography variant="h4" textAlign="center" fontWeight="bold" gutterBottom>
            🚀 How It Works
          </Typography>
          <Typography textAlign="center" mb={4} color="text.secondary">
            Getting started is easy. Just follow three simple steps.
          </Typography>

          <Grid container spacing={4}>
            {[
              { step: '1. Register', desc: 'Create your profile and verify with OTP sent to email & phone.' },
              { step: '2. Set Goals', desc: 'Tell us your fitness goals and current stats.' },
              { step: '3. Start Training', desc: 'Get personalized workouts and nutrition guidance.' },
            ].map((item, idx) => (
              <Grid item xs={12} sm={4} key={idx}>
                <Paper elevation={3} sx={{ p: 3, borderRadius: 3, textAlign: 'center' }}>
                  <Typography variant="h6" fontWeight="bold">{item.step}</Typography>
                  <Typography color="text.secondary">{item.desc}</Typography>
                </Paper>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* Call to Action */}
      <Container maxWidth="sm" sx={{ textAlign: 'center', py: 8 }}>
        <Typography variant="h4" fontWeight="bold" mb={2}>
          Ready to Transform Your Lifestyle?
        </Typography>
        <Typography color="text.secondary" mb={3}>
          Join thousands already making progress with FitLife.
        </Typography>
        <Button
          variant="contained"
          color="primary"
          size="large"
          sx={{ px: 5, py: 1.5, borderRadius: 5, fontWeight: 'bold' }}
          onClick={() => navigate('/signup')}
        >
          Join Now
        </Button>
      </Container>
    </Box>
  );
};

export default Home;
