import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Stack, Button } from '@mui/material';
import Logo from '../assets/images/Logo.png';

const Navbar = () => {
  const isAuthenticated = !!localStorage.getItem("user");

  const navigate = useNavigate();

  const handleExerciseClick = () => {
    if (isAuthenticated) {
      navigate('/exercise');
    } else {
      alert("Please login to access exercises");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("user");
    window.location.reload();
  };

  return (
    <Stack
      direction="row"
      justifyContent="space-between"
      alignItems="center"
      sx={{
        gap: { sm: '50px', xs: '20px' },
        mt: { sm: '32px', xs: '20px' },
        px: "20px",
        position: 'relative',
      }}
    >
      {/* Logo */}
      <Link to="/" style={{ position: 'absolute', left: '20px' }}>
        <img src={Logo} alt="logo" style={{ width: '60px', height: '60px' }} />
      </Link>

      {/* Navigation Links */}
      <Stack
        direction="row"
        gap="40px"
        fontFamily="Alegreya"
        fontSize="24px"
        alignItems="center"
        sx={{ margin: '0 auto' }}
      >
        <Link to="/" style={{ textDecoration: 'none', color: '#3A1212' }}>Home</Link>
        <Link to="/about-us" style={{ textDecoration: 'none', color: '#3A1212' }}>About Us</Link>
        <Link to="/contact-us" style={{ textDecoration: 'none', color: '#3A1212' }}>Contact Us</Link>
        <span onClick={handleExerciseClick} style={{ cursor: 'pointer', color: '#3A1212' }}>
          Exercise
        </span>
      </Stack>

      {/* Right-side Options */}
      <Stack direction="row" alignItems="center" spacing={2}>
        {isAuthenticated ? (
          <Button
            onClick={handleLogout}
            sx={{ color: "#3A1212", textTransform: "none", fontSize: '18px' }}
          >
            Logout
          </Button>
        ) : (
          <Link to="/login" style={{ textDecoration: 'none', color: '#3A1212', fontSize: '18px' }}>
            Login
          </Link>
        )}
      </Stack>
    </Stack>
  );
};

export default Navbar;