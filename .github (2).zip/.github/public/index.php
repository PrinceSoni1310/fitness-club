<?php
echo "<h1>Welcome to Fitness Club Backend</h1>";
echo "<p>Your PHP is running successfully.</p>";
?>
