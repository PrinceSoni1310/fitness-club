import React from "react";
import { Box, Typography, Stack, Card, CardMedia, CardContent } from "@mui/material";
import FitnessImage from "../assets/images/about-fitness.jpg";
import ChallengeImage from "../assets/images/about-challenge.jpg";
import DietImage from "../assets/images/about-diet.jpg";
import HelpImage from "../assets/images/about-help.jpg";

const AboutUs = () => {
  return (
    <Box sx={{ p: { xs: 2, md: 4 }, textAlign: "center", bgcolor: "#f5f5f5", borderRadius: "12px", boxShadow: 3 }}>
      <Typography variant="h3" fontWeight="bold" color="#FF2625" mb={4}>
        About FITNESS CLUB
      </Typography>
      <Typography variant="body1" fontSize="18px" mb={4} maxWidth="800px" mx="auto">
        Welcome to FITNESS CLUB – your one-stop solution for personalized fitness training and well-being. 
        Our platform empowers users to begin their fitness journey with guided exercises, video tutorials, tailored diet plans, and challenges 
        to build confidence and consistency. Access is exclusive to registered users via mobile number or email.
      </Typography>

      <Stack direction={{ xs: "column", md: "row" }} spacing={4} justifyContent="center" alignItems="center">
        <Card sx={{ maxWidth: 345, boxShadow: 5 }}>
          <CardMedia
            component="img"
            height="200"
            image={FitnessImage}
            alt="Fitness Training"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Guided Exercises
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Get access to age-based exercises and detailed video tutorials designed by experts.
            </Typography>
          </CardContent>
        </Card>

        <Card sx={{ maxWidth: 345, boxShadow: 5 }}>
          <CardMedia
            component="img"
            height="200"
            image={DietImage}
            alt="Diet Plan"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Personalized Diet Plans
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Stay healthy with personalized diet plans based on your age and body goals.
            </Typography>
          </CardContent>
        </Card>

        <Card sx={{ maxWidth: 345, boxShadow: 5 }}>
          <CardMedia
            component="img"
            height="200"
            image={ChallengeImage}
            alt="Fitness Challenges"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              Confidence Challenges
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Unlock achievements by completing fun challenges that help build fitness habits.
            </Typography>
          </CardContent>
        </Card>
      </Stack>

      <Box mt={6}>
        <Card sx={{ maxWidth: 800, mx: "auto", boxShadow: 4 }}>
          <CardMedia
            component="img"
            height="200"
            image={HelpImage}
            alt="Contact Help"
          />
          <CardContent>
            <Typography variant="h6">
              📞 Contact us: <a href="tel:+919023482484">+91 90234 82484</a>
            </Typography>
            <Typography variant="h6">
              📧 Email: <a href="mailto:princestudent1310@gmail.com">princestudent1310@gmail.com</a>
            </Typography>
          </CardContent>
        </Card>
      </Box>
    </Box>
  );
};

export default AboutUs;
